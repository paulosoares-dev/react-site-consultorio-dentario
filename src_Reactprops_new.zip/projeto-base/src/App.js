import './App.css';
import Rotas from './Rotas';

function App() {
  return (
    <div className="App">
      <Rotas />
    </div>
  );
}

export default App;
